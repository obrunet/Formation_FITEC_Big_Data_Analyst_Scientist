package com.jems.stream

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.execution.streaming.FileStreamSource.Timestamp
import org.apache.spark.sql.types._
import org.apache.spark.sql.functions._

object StreamingSampleJSON extends App {
/*
  val spark = SparkSession.builder.appName("Spark-Kafka-Integration").master("local").getOrCreate()
  val mySchema = StructType(Array(

    StructField("data1", StringType),

    StructField("data2", StringType),

    StructField("data3", StringType),

    StructField("data4", StringType),

    StructField("data5", StringType),
    StructField("data6", StringType),

    StructField("data7", StringType)

  ))

  val df = spark

    .readStream

    .format("kafka")

    .option("kafka.bootstrap.servers", "localhost:9092")

    .option("subscribe", "topicDataRaw")

    .load()

  val df1 = df.selectExpr("CAST(value AS STRING)", "CAST(timestamp AS TIMESTAMP)").as[(String, Timestamp)]

    //.select(from_json(col("value", mySchema).as("data"), $"timestamp")

    .select("data.*", "timestamp")
  df.writeStream

    .format("console")

    .option("truncate","false")

    .start()

    .awaitTermination()*/
}
