package com.jems.stream

import org.apache.spark.sql.SparkSession

import org.apache.spark.sql.functions._


object StreamingSample extends App {

  val spark = SparkSession.builder.appName("Spark-Kafka-Integration").master("local").getOrCreate()
  spark.sparkContext.setLogLevel("ERROR")

  val df = spark

    .readStream

    .format("kafka")

    .option("kafka.bootstrap.servers", "localhost:9092")

    .option("subscribe", "topicDataRaw")

    .load()

  import spark.implicits._

  //V1

  val df1 = df.selectExpr("CAST(value AS STRING)").as[String]

    .withColumn("date",split(col("value"),"\t")(0))
    .withColumn("ouv",split(col("value"),"\t")(1))
    .withColumn("haut",split(col("value"),"\t")(2))
    .withColumn("bas",split(col("value"),"\t")(3))
    .withColumn("clot",split(col("value"),"\t")(4))
    .withColumn("vol",split(col("value"),"\t")(5))
    .withColumn("devise",split(col("value"),"\t")(6))
    //.drop("value")

  df1
    .writeStream
    .format("console")
    .option("truncate","true")
    .start()

    .awaitTermination()
//  df1.take(10).foreach(println)
}
